# constallation-vpc
## Version 0.1.1a0
### **<span style="color:red;">Warning | Do Not Use for anything important</span>**
**The version _0.1.1a0_ is a package from the alpha stages and also pre-release** and has **undergone very minimal testing.** This version was built on `08/09/2024` Please use something more modern and closer to latest as this package is not secure for any actual use and its release serves archival means. 

***
### Changelist
- #### **<span style="color:red;">0.1.1a0</span>**
  - Added VPC Class