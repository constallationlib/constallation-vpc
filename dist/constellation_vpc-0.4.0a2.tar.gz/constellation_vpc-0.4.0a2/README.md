# constallation-vpc
## Version 0.4.0a2
### **<span style="color:red;">Warning | Do Not Use for anything important</span>**
**The version _0.4.0a2 is a package from the alpha stages and also pre-release** and has **undergone very minimal testing.** This version was built on `08/15/2024` Please use something more modern and closer to latest as this package is not secure for any actual use and its release serves archival means. 

***
### Changelist
- #### **<span style="color:red;">0.4.0a0</span>**
  - Added NAT Gateway funcs to _vpc base class
  - Created `NATGateway` class
  - Wrote docs for `NatGateway`
- #### **<span style="color:red;">0.4.0a1</span>**
  - Added Error Handling for `_vpc` NAT Gateway functions. 
- #### **<span style="color:red;">0.4.0a2</span>**
  - Better Unknown-Error Handling