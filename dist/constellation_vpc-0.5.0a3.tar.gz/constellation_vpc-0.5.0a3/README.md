# constallation-vpc
## Version 0.5.0a3
### **<span style="color:red;">Warning | Do Not Use for anything important</span>**
**The version _0.5.0a3 is a package from the alpha stages and also pre-release** and has **undergone very minimal testing.** This version was built on `08/10/2024` Please use something more modern and closer to latest as this package is not secure for any actual use and its release serves archival means. 

***
### Changelist
- #### **<span style="color:red;">0.5.0a0</span>**
  - Added Peering Connection funcs to _vpc base class
  - Created `PeeringConnection` class
- #### **<span style="color:red;">0.5.0a1</span>**
  - Write Peering Connection Docs
- #### **<span style="color:red;">0.5.0a2</span>**
  - Added Internet Gateways into vpc.py
- #### **<span style="color:red;">0.5.0a3 (planned)</span>**
  - Added NAT Gateways into vpc.py
  - Added Peering Connections into vpc.py
- #### **<span style="color:red;">0.5.0a4 (planned)</span>**
  - Added ErrorHandling for Peering Connections
  - Write Errors Docs
  - Write a better index page